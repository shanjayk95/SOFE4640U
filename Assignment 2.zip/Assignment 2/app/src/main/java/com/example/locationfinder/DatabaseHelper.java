package com.example.locationfinder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";

    private static final String TABLE_NAME = "location_table";
    private static final String COL1 = "ID";
    private static final String COL2 = "ADDRESS";
    private static final String COL3 = "LATITUDE";
    private static final String COL4 = "LONGITUDE";

    public DatabaseHelper(Context context){
        super(context, TABLE_NAME, null, 1);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL2 + " TEXT, " + COL3 + " TEXT, " + COL4 + " TEXT)";
        db.execSQL(createTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    //Function to save data into db
    public boolean addData(String address, double latitude, double longitude){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, address);
        contentValues.put(COL3, latitude);
        contentValues.put(COL4, longitude);

        Log.d(TAG, "addData: Adding " + address + ", " + latitude + ", " + longitude + " to " + TABLE_NAME);

        long result = db.insert(TABLE_NAME, null, contentValues);

        //Check if data was correctly inserted to the table
        return result != -1;
    }

    public boolean removeData(String address, double latitude, double longitude){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, address);
        contentValues.put(COL3, latitude);
        contentValues.put(COL4, longitude);

        Log.d(TAG, "removeData: Removing " + address + ", " + latitude + ", " + longitude + " to " + TABLE_NAME);

        //long result = db.delete(TABLE_NAME, null, contentValues);
        return true;
    }

    public boolean updateData(String address, double latitude, double longitude){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, address);
        contentValues.put(COL3, latitude);
        contentValues.put(COL4, longitude);

        Log.d(TAG, "updateData: Updating " + address + ", " + latitude + ", " + longitude + " to " + TABLE_NAME);

        //long result = db.delete(TABLE_NAME, null, contentValues);
        return true;
    }

    //Function to get data from db
    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query, null);
        return data;
    }
}