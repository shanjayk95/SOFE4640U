package com.example.locationfinder;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.location.Address;
import android.location.Geocoder;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    DatabaseHelper mDBH;
    private Button searchBtn, addBtn, updateBtn, deleteBtn;
    private EditText longField, latiField, addrField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Referencing all buttons
        searchBtn = (Button) findViewById(R.id.searchButton);
        addBtn = (Button) findViewById(R.id.addButton);
        updateBtn = (Button) findViewById(R.id.updateButton);
        deleteBtn = (Button) findViewById(R.id.deleteButton);
        //Referencing all EditText fields
        longField = (EditText) findViewById(R.id.longitudeField);
        latiField = (EditText) findViewById(R.id.latitudeField);
        addrField = (EditText) findViewById(R.id.addressField);
        mDBH = new DatabaseHelper(this);

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (addrField.length() !=0 && latiField.length() == 0 && longField.length() == 0){
                    String address = addrField.getText().toString();
                    int index;
                    Cursor data = mDBH.getData();
                    ArrayList<String> addrData = new ArrayList<>();
                    ArrayList<String> latiData = new ArrayList<>();
                    ArrayList<String> longiData = new ArrayList<>();
                    while (data.moveToNext()){
                        addrData.add(data.getString(1));
                        latiData.add(data.getString(2));
                        longiData.add(data.getString(3));
                    }

                    if (addrData.contains(address)){
                        index = addrData.indexOf(address);
                        longField.setText(longiData.get(index));
                        latiField.setText(latiData.get(index));
                        toastMessage("Saved coordinates found!");
                    } else {
                        toastMessage("This address isn't already saved!");
                    }
                } else {
                    try {
                        double latitude = Double.parseDouble(latiField.getText().toString());
                        double longitude = Double.parseDouble(longField.getText().toString());
                        String address = getAddress(latitude, longitude);
                        addrField.setText(address);
                    } catch (Exception e){
                        toastMessage("No values entered!");
                    }
                }
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (addrField.length() !=0 || (latiField.length() != 0 && longField.length() != 0)){
                    removeData(addrField.getText().toString(), Double.parseDouble(latiField.getText().toString()), Double.parseDouble(longField.getText().toString()));
                }
            }
        });

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    double latitude = Double.parseDouble(latiField.getText().toString());
                    double longitude = Double.parseDouble(longField.getText().toString());
                    String address = addrField.getText().toString();
                    if (address.length() != 0) {
                        addData(address, latitude, longitude);
                    } else {
                        toastMessage("Please enter the coordinates to acquire a location!");
                    }
                } catch (Exception e){
                    toastMessage("Invalid data!");
                }
            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (addrField.length() !=0 && latiField.length() != 0 && longField.length() != 0){
                    updateData(addrField.getText().toString(), Double.parseDouble(latiField.getText().toString()), Double.parseDouble(longField.getText().toString()));
                }
            }
        });
    }

    public String getAddress(double latitude, double longitude){
        try {
            Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude,1);
            String address = addresses.get(0).getAddressLine(0);
            return address;
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    public void addData(String address, double latitude, double longitude){
        boolean insertData = mDBH.addData(address, latitude, longitude);

        if (insertData) {
            toastMessage("Data added successfully!");
        } else {
            toastMessage("Couldn't add data!");
        }
    }

    public void removeData(String address, double latitude, double longitude){
        boolean deleteData = mDBH.removeData(address, latitude, longitude);
        if (deleteData) {
            toastMessage("Data removed successfully!");
        } else {
            toastMessage("Couldn't remove data!");
        }
    }

    public void updateData(String address, double latitude, double longitude){
        boolean updateData = mDBH.updateData(address, latitude, longitude);
        if (updateData) {
            toastMessage("Data updated successfully!");
        } else {
            toastMessage("Couldn't update data!");
        }
    }

    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}