package com.example.emicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView resultBox = (TextView)findViewById(R.id.results);

        final Button button = findViewById(R.id.calculateButton); //Locates the button using its ID
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                calculate(resultBox); //Calls the calculate function
            }
        });
    }

    @SuppressLint({"SetTextI18n", "DefaultLocale"}) //IDE suggested bug handling
    private void calculate(TextView resultBox){
        TextView principalText = (TextView)findViewById(R.id.mortgageAmount); //Gets the principal amount from the input field
        TextView durationText = (TextView)findViewById(R.id.durationInput);
        TextView interestText = (TextView)findViewById(R.id.interestRate);
        double principal = Double.parseDouble(principalText.getText().toString()); //Converts the input value to a double
        double duration = (Double.parseDouble(durationText.getText().toString()))*12;
        double interest = ((Double.parseDouble(interestText.getText().toString()))/12)/100;
        double numerator = interest * Math.pow((1+interest), duration);
        double denominator = Math.pow((1+interest), duration) - 1;
        double result = principal * (numerator/denominator); //amortization calculation
        resultBox.setText("Monthly Payment: $" + String.valueOf(String.format("%.2f", result))); //displays the formatted result to the main view
    }
}